# Ansible Collection - ansible.passwordstate

This collection is used to manage Passwordstate entries.